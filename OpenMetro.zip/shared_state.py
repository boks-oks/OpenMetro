# This file holds global state that is shared across different modules.
import os
# The user's coordinates (latitude, longitude) will be stored here
# after being fetched by the location module.
coords = None
# A flag to indicate if the initial location fetch has started.
location_task_started = False

# Path for the error tile template.
# This tile is used when there is an error fetching data from the RSS feed.
# It provides a fallback tile with an error message.
ERROR_TILE_PATH = os.path.join(os.path.dirname(__file__), "Tiles", "error.xml")
PLACEHOLDER_IMAGE_URL = "https://placehold.co/400x400/transparent/FFFFFF/png?text=Placeholder%0ATile"