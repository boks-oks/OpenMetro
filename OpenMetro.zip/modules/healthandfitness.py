import html
import os
from xml.sax.saxutils import escape
import feedparser
import re
from html import unescape
from mitmproxy import http
from shared_state import ERROR_TILE_PATH

URL_PATTERN = "api.health.appex.bing.com"
HEALTH_TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "..", "Tiles", "healthandfitness.xml")

RSS_FEED_URL = "https://www.npr.org/rss/rss.php?id=1128"

tracking_pixel_urls = [
    "https://media.npr.org/include/images/tracking/npr-rss-pixel.png",
]

def is_tracking_pixel(url):
    return any(t in url for t in tracking_pixel_urls)

import re
from html import unescape

def fetch_health_story():
    feed = feedparser.parse(RSS_FEED_URL)

    for entry in feed.entries:
        content = entry.get("content", [{}])[0].get("value", "")

        # Find all images in content
        matches = re.findall(r"<img\s+[^>]*src=['\"]([^'\"]+)['\"]", content)

        # Filter out tracking pixels
        valid_images = [url for url in matches if not is_tracking_pixel(url)]

        if valid_images:
            return {
                "title": unescape(entry.title),
                "img_url": valid_images[0]  # first valid image
            }

    return None


def render_health_tile(img_url, title):
    with open(HEALTH_TEMPLATE_PATH, "r", encoding="utf-8") as f:
        template = f.read()
    return template.format(img_url=img_url, article_text=title)


def handle_request(flow: http.HTTPFlow):
    if "GetLiveTileMetaData" in flow.request.path:
        print(f"[Health & Fitness] Intercepted: {flow.request.pretty_url}")

        data = fetch_health_story()
        if data:
            img_url = data["img_url"]
            resized_url = f"https://images.weserv.nl/?url={img_url}&w=400&h=400&fit=cover"
            safe_url   = escape(resized_url, {'"': '&quot;'})
            safe_title = escape(data["title"])
            tile_str   = render_health_tile(safe_url, safe_title)
        else:
            with open(ERROR_TILE_PATH, "r", encoding="utf-8") as f:
                tile_str = f.read()

        # Debug once if still blank
        # print("[DEBUG XML]\n", tile_str)

        flow.response = http.Response.make(
            200,
            tile_str.encode("utf-8"),            # <- bytes!
            {"Content-Type": "application/xml; charset=utf-8"}
        )
