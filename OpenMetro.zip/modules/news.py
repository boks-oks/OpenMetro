# modules/news.py
import os
from xml.sax import saxutils
import requests
import xml.etree.ElementTree as ET
import mitmproxy.http
from shared_state import ERROR_TILE_PATH

# URL pattern to intercept for this module
URL_PATTERN = "/news/"

# --- Module-specific variables and constants ---

FEED_URL = "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml"
NEWS_TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "..", "Tiles", "news.xml")

# --- Helper Functions ---

def load_news_tile_template():
    """
    Loads the news tile XML template from the specified file path.
    """
    print(f"Loading template from: {NEWS_TEMPLATE_PATH}")
    try:
        with open(NEWS_TEMPLATE_PATH, "r") as f:
            return f.read()
    except FileNotFoundError:
        print(f"Error: News tile template not found at {NEWS_TEMPLATE_PATH}")
        return os.read(ERROR_TILE_PATH).encode("utf-8")
    except Exception as e:
        print(f"Error loading template from {NEWS_TEMPLATE_PATH}: {e}")
        return os.read(ERROR_TILE_PATH).encode("utf-8")


def get_news_data_from_rss():
    """
    Fetches news articles from the New York Times RSS feed.
    Parses the XML and extracts article titles and image URLs.
    Returns a list of dictionaries, each containing 'title' and 'image'.
    Limits to the first 4 articles as per requirement for different tiles.
    """
    try:
        if not FEED_URL:
            print("No news RSS feed URL configured.")
            return []
        response = requests.get(FEED_URL)
        if response.status_code != 200:
            print(f"Failed to fetch news data: {response.status_code}")
            return []
        root = ET.fromstring(response.content)
        # Find the 'channel' element in the RSS feed
        channel = root.find("channel")
        if channel is None:
            print("No 'channel' element found in RSS feed.")
            return []
        articles = []
        # Iterate through each 'item' (article) in the channel
        for item in channel.findall("item"):
            title = item.findtext("title", default="No Title").strip()
            image_url = ""
            # Attempt to find image from media:content (common for RSS images)
            for media in item.findall("{http://search.yahoo.com/mrss/}content"):
                image_url = media.attrib.get("url", "")
                if image_url:
                    break
            # If no image found in media:content, check for 'enclosure'
            if not image_url:
                enclosure = item.find("enclosure")
                if enclosure is not None:
                    image_url = enclosure.attrib.get("url", "")
            # Fallback image if no image URL is found
            if not image_url:
                image_url = "https://placehold.co/500x500.png?text=No+Image"
            articles.append({"title": title, "image": image_url})
            # Stop after collecting 4 articles as these are for the 4 specific tiles
            if len(articles) >= 4:
                break
        return articles
    except Exception as e:
        print(f"Error fetching news data: {e}")
        return []
    
def generate_news_tile_content(articles, tile_type="Today.xml"):
    """
    Generates the XML content for a news tile based on the selected article and template.
    It now correctly maps the tile_type to an article index.
    """
    template = load_news_tile_template() # This will now load from the file
    
    # Determine which article to use based on tile_type
    article_index = 0 # Default to the first article
    if tile_type == "Today.xml":
        article_index = 0
    elif tile_type == "2.xml":
        article_index = 1
    elif tile_type == "3.xml":
        article_index = 2
    elif tile_type == "4.xml":
        article_index = 3
    
    # Safely get the article data, providing fallbacks if the index is out of bounds
    if article_index < len(articles):
        selected_article = articles[article_index]
        article_text = selected_article.get("title", "No news available.")
        img_url = selected_article.get("image", "https://placehold.co/500x500.png?text=No+Image")
    else:
        article_text = "More articles coming soon!"
        img_url = "https://placehold.co/500x500.png?text=No+Article"

    resized_url = f"https://images.weserv.nl/?url={img_url}&w=400&h=400&fit=cover"

    # Create the mapping for the template placeholders
    mapping = {
        "article_text": saxutils.escape(article_text),
        "img_url": saxutils.escape(resized_url)
    }

    try:
        content = template.format(**mapping)
    except KeyError as e:
        print(f"[generateNewsTileContent] Missing placeholder in template: {e}")
        # Fallback to an error tile if template formatting fails
        with open(ERROR_TILE_PATH, "r") as f:
            content = f.read()
    return content.encode("utf-8")

# --- Main Request Handler for this Module ---

def handle_request(flow: mitmproxy.http.HTTPFlow):
    """
    This function is called from the main script when a matching URL is intercepted.
    It fetches news data and generates the appropriate tile content based on the URL.
    """
    print(f"News tile request detected: {flow.request.pretty_url}")
    
    # Fetch all available articles (up to 4)
    articles = get_news_data_from_rss()
    url = flow.request.pretty_url.lower()

    # Determine tile type based on the URL path
    tile_type = "Today.xml" # Default type
    if "today.xml" in url:
        tile_type = "Today.xml"
    elif "2.xml" in url:
        tile_type = "2.xml"
    elif "3.xml" in url:
        tile_type = "3.xml"
    elif "4.xml" in url:
        tile_type = "4.xml"
    
    # Check if any articles were fetched
    if not articles:
        print("No news articles found, returning error tile.")
        with open(ERROR_TILE_PATH, "rb") as f:
            flow.response = mitmproxy.http.Response.make(200, f.read(), {"Content-Type": "text/xml"})
    else:
        # Generate the news tile content using the full list of articles and the determined tile_type
        news_tile_content = generate_news_tile_content(articles, tile_type)
        flow.response = mitmproxy.http.Response.make(200, news_tile_content, {"Content-Type": "text/xml"})
        print(f"News tile response sent for {tile_type}.")
