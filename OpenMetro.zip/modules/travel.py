import os
import html
import random
import re
from xml.sax.saxutils import escape
from mitmproxy import http
import requests
from shared_state import ERROR_TILE_PATH

URL_PATTERN = "travel.tile.appex.bing.com"
TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "..", "Tiles", "travel.xml")

API = "https://commons.wikimedia.org/w/api.php"


import random, requests, os
from xml.sax.saxutils import escape

COMMONS_API = "https://commons.wikimedia.org/w/api.php"
USER_AGENT   = "OpenMetro/1.0 (+https://github.com/opentile/openmetro)"

def fetch_random_landscape():
    """
    Returns: dict | None
        {
          "img_url" : direct 600-px thumbnail,
          "title"   : cleaned title for tile text
        }
    Falls back to None on error.
    """

    # 1. Pull up to 50 files in the Featured Landscapes category
    cat_params = {
        "action"  : "query",
        "format"  : "json",
        "list"    : "categorymembers",
        "cmtitle" : "Category:Featured_pictures_of_landscapes",
        "cmlimit" : "50",
        "cmtype"  : "file",
    }
    r = requests.get(COMMONS_API, params=cat_params,
                     headers={"User-Agent": USER_AGENT}, timeout=10)
    r.raise_for_status()
    files = r.json()["query"]["categorymembers"]
    if not files:
        return None

    # Shuffle so we don't hammer the same file every run
    random.shuffle(files)

    # 2. Walk the shuffled list until we hit a landscape image
    for file in files:
        info_params = {
            "action": "query",
            "format": "json",
            "titles": file["title"],   # e.g. "File:Grand_Canyon.jpg"
            "prop"  : "imageinfo",
            "iiprop": "url|size",
            "iiurlwidth": "600"
        }
        r2 = requests.get(COMMONS_API, params=info_params,
                          headers={"User-Agent": USER_AGENT}, timeout=10)
        r2.raise_for_status()
        page = next(iter(r2.json()["query"]["pages"].values()))
        imginfo = page.get("imageinfo", [{}])[0]

        w = imginfo.get("width", 0)
        h = imginfo.get("height", 0)
        if w > h:                               # landscape check
            thumb = imginfo.get("thumburl") or imginfo.get("url")
            if not thumb:
                continue

            raw_title = page["title"].split(":",1)[-1]      # drop "File:"
            name_only = os.path.splitext(raw_title)[0]      # drop .jpg/.png…
            clean_title = name_only.replace("_", " ")

            return {"img_url": thumb, "title": clean_title}

    # If we never found one:
    return None

def render_travel_tile(img_url, title):
    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        template = f.read()
    return template.format(img_url=img_url, article_text=title)

def handle_request(flow: http.HTTPFlow):
    if "livetile.xml" in flow.request.path:
        print(f"[Travel] Intercepted: {flow.request.pretty_url}")

        data = fetch_random_landscape()
        if data:
            img_url = data["img_url"]
            resized_url = f"https://images.weserv.nl/?url={img_url}&w=400&h=400&fit=cover"
            safe_url   = escape(resized_url, {'"': '&quot;'})
            safe_title = escape(data["title"])
            tile_str   = render_travel_tile(safe_url, safe_title)

        else:
            with open(ERROR_TILE_PATH, "r", encoding="utf-8") as f:
                tile_str = f.read()

        flow.response = http.Response.make(
            200,
            tile_str.encode("utf-8"),
            {"Content-Type": "application/xml; charset=utf-8"}
        )
