# modules/location.py
import asyncio
import json
import threading
import http.server
import socketserver
import webbrowser
import queue

# Import the shared state so this module can update the coordinates
import shared_state

HTML_CONTENT = """
<!DOCTYPE html>
<html>
  <head>
    <title>Geo Grabber</title>
    <style>
      /* Basic styles for the page layout and color scheme */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
        background: #181a20; /* Dark background */
        color: #f1f1f1; /* White text */
        font-family: sans-serif;
      }
      /* Use flexbox to center the content on the page */
      body {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        text-align: center;
      }
      /* Style for the container div to ensure its content is also centered */
      .centered {
        display: flex;
        flex-direction: column;
        align-items: center;
      }
      /* Add some margin to space out the interactive elements */
      input, button {
        margin: 0.5em 0;
        font-size: 1em;
      }
      /* Keep the error message red to make it noticeable */
      .error {
        color: #ff6b6b;
        margin-top: 0.5em;
      }
    </style>
    <script>
      async function sendCoords(coords) {
        try {
          // This fetch will likely fail in a sandboxed environment
          // but is kept for functional integrity.
          await fetch("/", {
            method: "POST",
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(coords)
          });
          window.close();
        } catch (e) {
          showError("Failed to send location.");
        }
      }

      function showError(msg) {
        document.getElementById("error").textContent = msg;
      }

      async function sendLocation() {
        if (!navigator.geolocation) {
          showError("Geolocation not supported.");
          return;
        }
        navigator.geolocation.getCurrentPosition(pos => {
          const coords = {
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude
          };
          sendCoords(coords);
        }, err => {
          showError("Error getting location: " + err.message);
        });
      }

      async function manualLookup() {
        const input = document.getElementById("manualInput").value.trim();
        if (!input) {
          showError("Please enter a location.");
          return;
        }
        showError(""); // Clear previous errors
        try {
          // Use OpenStreetMap's Nominatim API for geocoding
          const url = "https://nominatim.openstreetmap.org/search?format=json&q=" + encodeURIComponent(input);
          const resp = await fetch(url, {headers: {"Accept": "application/json"}});
          const data = await resp.json();

          if (data.length === 0) {
            showError("Location not found.");
            return;
          }

          const coords = {
            latitude: parseFloat(data[0].lat),
            longitude: parseFloat(data[0].lon)
          };
          sendCoords(coords);
        } catch (e) {
          showError("Error looking up location.");
        }
      }

      // Assign click handlers after the DOM is fully loaded
      window.onload = function() {
        document.getElementById("geoBtn").onclick = sendLocation;
        document.getElementById("manualBtn").onclick = manualLookup;
      };
    </script>
  </head>
  <body>
    <div class="centered">
      <h2>Choose Location</h2>
      <button id="geoBtn">Use My Device Location</button>
      <input id="manualInput" type="text" placeholder="Enter location..." autocomplete="off" />
      <button id="manualBtn">Lookup</button>
      <div id="error" class="error"></div>
    </div>
  </body>
</html>
"""

async def get_precise_location():
    """
    Opens the user's default browser to get geolocation and receives it via a local HTTP server.
    """
    location_queue = queue.Queue()

    class LocationHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == "/":
                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(HTML_CONTENT.encode("utf-8"))
            else:
                self.send_response(404)
                self.end_headers()

        def do_POST(self):
            content_length = int(self.headers["Content-Length"])
            post_data = self.rfile.read(content_length)
            try:
                coords_data = json.loads(post_data.decode("utf-8"))
                location_queue.put(coords_data)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"OK")
            except Exception as e:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"Bad Request")

        def log_message(self, format, *args):
            # Suppress console logging for the server
            return

    with socketserver.TCPServer(("localhost", 0), LocationHandler) as httpd:
        port = httpd.server_address[1]
        url = f"http://localhost:{port}/";

        server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        server_thread.start()

        webbrowser.open(url)

        try:
            coords_data = location_queue.get(timeout=120)  # 2 minute timeout
        except queue.Empty:
            coords_data = {} # Return empty dict on timeout

        httpd.shutdown()
        return coords_data

async def fetch_coords():
    """
    Asynchronously fetches coordinates and updates the shared state.
    """
    coords_data = await get_precise_location()
    if coords_data:
        shared_state.coords = coords_data
        print(f"Got location: {shared_state.coords}")
    else:
        print("Could not retrieve location.")

