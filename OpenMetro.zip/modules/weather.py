# modules/weather.py
import asyncio
import os
import requests
import json
from datetime import datetime, timezone
import mitmproxy.http

import shared_state

# URL pattern to intercept for this module
URL_PATTERN = "weather.tile.appex.bing.com/weatherservice.svc/livetilev2"

# --- Module-specific variables and constants ---
TILE_REFRESH_INTERVAL = 300  # 5 minutes
tile_xml_cache = None
tile_cache_time = None
total_accuweather_images = 18

ACCUWEATHER_IMAGE_MAP = {
    "01d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/01_02.jpg",
    "01n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/33.jpg",
    "04n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/33.jpg",
    "04d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/11.jpg",
    "02d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/03_04_05.jpg",
    "02n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/38.jpg",
    "03d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/03_04_05.jpg",
    "03n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/30_31_32_34_35_36_37.jpg",
    "09d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/12_13_39_40.jpg",
    "09n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/24_25_26.jpg",
    "10d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/14.jpg",
    "10n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/18.jpg",
    "11d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/15_41_42.jpg",
    "11n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/24_25_26.JPG",
    "13d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/19_43.jpg",
    "13n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/29.jpg",
    "50d": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/31.jpg",
    "50n": "http://vortex.accuweather.com/adc2010/hostedpages/w8api/bg310x310/11.jpg",
}
WMO_WEATHER_DESCRIPTIONS = {0:"Clear sky",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",45:"Fog",48:"Depositing rime fog",51:"Light drizzle",53:"Moderate drizzle",55:"Dense drizzle",56:"Light freezing drizzle",57:"Dense freezing drizzle",61:"Slight rain",63:"Moderate rain",65:"Heavy rain",66:"Light freezing rain",67:"Heavy freezing rain",71:"Slight snow fall",73:"Moderate snow fall",75:"Heavy snow fall",77:"Snow grains",80:"Slight rain showers",81:"Moderate rain showers",82:"Violent rain showers",85:"Slight snow showers",86:"Heavy snow showers",95:"Thunderstorm",96:"Thunderstorm with slight hail",99:"Thunderstorm with heavy hail"}
WMO_TO_MSN_ACCUWEATHER_CODE = {0:"01",1:"01",2:"02",3:"04",45:"50",48:"50",51:"09",53:"09",55:"09",56:"10",57:"10",61:"10",63:"10",65:"10",66:"10",67:"10",71:"13",73:"13",75:"13",77:"13",80:"09",81:"09",82:"09",85:"13",86:"13",95:"11",96:"11",99:"11"}

# --- Helper Functions ---

def _get_openmeteo_data(latitude, longitude, timezone="America/New_York"):
    openmeteo_url = "https://api.open-meteo.com/v1/forecast"
    params = {"latitude": latitude, "longitude": longitude, "current": "temperature_2m,weather_code,is_day", "daily": "temperature_2m_max,temperature_2m_min,weather_code", "timezone": timezone, "forecast_days": 2, "temperature_unit": "fahrenheit"}
    try:
        response = requests.get(openmeteo_url, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching OpenMeteo data: {e}")
        return None

def _get_msn_weather_code(wmo_code, is_day):
    common_code = WMO_TO_MSN_ACCUWEATHER_CODE.get(wmo_code, "01")
    day_night_suffix = "d" if is_day == 1 else "n"
    return f"{common_code}{day_night_suffix}"

def _get_weather_description(wmo_code):
    return WMO_WEATHER_DESCRIPTIONS.get(wmo_code, "Unknown weather")

def get_weather_image(weather_code):
    return ACCUWEATHER_IMAGE_MAP.get(weather_code)

def reverse_geocode(lat, lon):
    try:
        resp = requests.get("https://nominatim.openstreetmap.org/reverse", params={"lat": lat, "lon": lon, "format": "json"}, headers={"User-Agent": "OpenMetro/1.0"})
        if resp.ok:
            data = resp.json()
            address = data.get("address", {})
            for key in ("city", "town", "village", "hamlet"):
                if key in address:
                    return address[key]
            return data.get("display_name", "?")
        return "?"
    except Exception:
        return "?"

async def refresh_tile_data():
    global tile_xml_cache, tile_cache_time
    if shared_state.coords is None:
        print("Weather: No coordinates yet, skipping tile refresh.")
        return
    latitude = shared_state.coords.get("latitude", 42.75)
    longitude = shared_state.coords.get("longitude", 120.74)
    location_name = reverse_geocode(latitude, longitude)
    weather_data = _get_openmeteo_data(latitude, longitude)
    if not weather_data:
        print("Failed to get weather data from OpenMeteo.")
        tile_xml_cache = "<tile><visual version='2'><binding template='TileSquare150x150Block'><text id='1'>Error</text><text id='2'>No Weather Data</text></binding></visual></tile>"
        tile_cache_time = datetime.now(timezone.utc)
        return

    current_temp = int(weather_data["current"]["temperature_2m"])
    current_wmo_code = weather_data["current"]["weather_code"]
    is_day = weather_data["current"]["is_day"]
    weather_condition = _get_weather_description(current_wmo_code)
    daily_data = weather_data["daily"]
    today_high = int(daily_data["temperature_2m_max"][0]) if len(daily_data["temperature_2m_max"]) > 0 else "N/A"
    today_low = int(daily_data["temperature_2m_min"][0]) if len(daily_data["temperature_2m_min"]) > 0 else "N/A"
    today_wmo_code = daily_data["weather_code"][0] if len(daily_data["weather_code"]) > 0 else None
    today_description = _get_weather_description(today_wmo_code) if today_wmo_code is not None else "N/A"
    tomorrow_high = int(daily_data["temperature_2m_max"][1]) if len(daily_data["temperature_2m_max"]) > 1 else "N/A"
    tomorrow_low = int(daily_data["temperature_2m_min"][1]) if len(daily_data["temperature_2m_min"]) > 1 else "N/A"
    tomorrow_wmo_code = daily_data["weather_code"][1] if len(daily_data["weather_code"]) > 1 else None
    tomorrow_description = _get_weather_description(tomorrow_wmo_code) if tomorrow_wmo_code is not None else "N/A"
    weather_icon_code = _get_msn_weather_code(current_wmo_code, is_day)
    weather_icon_url = get_weather_image(weather_icon_code)
    template_dir = os.path.join(os.path.dirname(__file__), "..", "Tiles")
    template_path = os.path.join(template_dir, "weather.xml")

    if not os.path.exists(template_path):
        print("Weather tile template not found.")
        tile_xml_cache = "<tile><visual version='2'><binding template='TileSquare150x150Block'><text id='1'>Error</text><text id='2'>Template Missing</text></binding></visual></tile>"
        tile_cache_time = datetime.now(timezone.utc)
        return

    with open(template_path, "r") as template_file:
        template_content = template_file.read()
    populated_xml = template_content.format(current_temp=current_temp, location=location_name, weather_icon_url=weather_icon_url, weather_condition=weather_condition, high_temp=today_high, low_temp=today_low, msn_weather_large=weather_icon_url, today_description=today_description, tomorrow_high=tomorrow_high, tomorrow_low=tomorrow_low, tomorrow_description=tomorrow_description)
    tile_xml_cache = populated_xml
    tile_cache_time = datetime.now(timezone.utc)
    print("Weather tile data refreshed.")

async def periodic_tile_refresh():
    """Periodically refreshes the tile data in the background."""
    # Initial immediate refresh after getting coords
    while shared_state.coords is None:
        await asyncio.sleep(1) # Wait for coordinates to be available
    await refresh_tile_data()

    while True:
        await asyncio.sleep(TILE_REFRESH_INTERVAL)
        await refresh_tile_data()

# --- Main Request Handler for this Module ---

def handle_request(flow: mitmproxy.http.HTTPFlow):
    """
    This function is called from the main script when a matching URL is intercepted.
    """
    global tile_xml_cache, tile_cache_time
    print("Weather tile request detected.")

    cache_age = (datetime.now(timezone.utc) - tile_cache_time).total_seconds() if tile_cache_time else None
    if tile_xml_cache is None or (cache_age is not None and cache_age > TILE_REFRESH_INTERVAL):
        print("Weather tile cache is stale or missing, waiting for refresh...")
        # In a modular async context, we rely on the periodic refresh.
        # If the cache is empty, we show a waiting message.
        if tile_xml_cache is None:
            flow.response = mitmproxy.http.Response.make(200, os.read(shared_state.ERROR_TILE_PATH, "rb"), {"Content-Type": "text/xml"})
            return

    if tile_xml_cache:
        flow.response = mitmproxy.http.Response.make(200, tile_xml_cache.encode("utf-8"), {"Content-Type": "text/xml"})
        print("Weather tile response sent from cache.")
    else:
        flow.response = mitmproxy.http.Response.make(200, os.read(shared_state.ERROR_TILE_PATH, "rb"), {"Content-Type": "text/xml"})
