import os
from mitmproxy import http

URL_PATTERN = "cdf-anon.xboxlive.com"
GAME_TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "..", "Tiles", "notimplemented.xml")

def handle_request(flow: http.HTTPFlow):
    # Stub.
    if "Tile-Games" in flow.request.path:
        print(f"[Games] Intercepted: {flow.request.pretty_url}")
        data = None
        with open(GAME_TEMPLATE_PATH) as f:
            tile = f.read()

        flow.response = http.Response.make(
            200,
            tile,
            {"Content-Type": "application/xml; charset=utf-8"}
        )
