# modules/sports.py
import os, html, feedparser, re, requests
from xml.sax.saxutils import escape
from mitmproxy import http
from shared_state import ERROR_TILE_PATH   # use a fallback of your choice

# ------------------------------------------------------------------
#  CONFIG
# ------------------------------------------------------------------
URL_PATTERN   = "en-us.appex-rf.msn.com"          # what the old Sports tile points to
TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "..", "Tiles", "sports.xml")
RSS_FEED_URL  = "https://www.espn.com/espn/rss/news"

# ------------------------------------------------------------------
#  HELPERS
# ------------------------------------------------------------------

def fetch_sports_story():
    feed = feedparser.parse(RSS_FEED_URL)
    feed_logo = feed.feed.get("image", {}).get("href", "https://upload.wikimedia.org/wikipedia/commons/2/2f/ESPN_wordmark.svg")  # Fallback logo

    entry = feed.entries[0] if feed.entries else None
    if not entry:
        raise ValueError("No entries in sports feed.")

    title = entry.get("title", "No title")
    summary = entry.get("description", "")
    url = entry.get("link", "#")

    # ESPN feed does NOT have enclosures; fall back to feed_logo
    img_url = feed_logo

    return {
        "title": title,
        "summary": summary,
        "url": url,
        "img": img_url,
    }


def render_sports_tile(img_url, title):
    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        template = f.read()
    return template.format(img_url=img_url, article_text=title)


# ------------------------------------------------------------------
#  MAIN HANDLER
# ------------------------------------------------------------------
def handle_request(flow: http.HTTPFlow):
    if "Sports" in flow.request.pretty_url:
        print(f"[Sports] Intercepted: {flow.request.pretty_url}")

        data = fetch_sports_story()
        if data:
            # Resize via weserv for <400×400> and escape XML specials
            resized = f"https://images.weserv.nl/?url={data['img']}&w=400&h=400&fit=cover"
            safe_url   = escape(resized, {'"': '&quot;'})
            safe_title = escape(data["title"])
            tile_str   = render_sports_tile(safe_url, safe_title)
        else:
            with open(ERROR_TILE_PATH, "r", encoding="utf-8") as f:
                tile_str = f.read()

        flow.response = http.Response.make(
            200,
            tile_str.encode("utf-8"),
            {"Content-Type": "application/xml; charset=utf-8"}
    )
