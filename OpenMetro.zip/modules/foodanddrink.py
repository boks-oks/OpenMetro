import os
from mitmproxy import http
import feedparser
import requests

URL_PATTERN = "foodanddrink.services.appex.bing.com"
FOOD_AND_DRINK_TEMPLATE_PATH = os.path.join(
    os.path.dirname(__file__), "..", "Tiles", "foodanddrink.xml"
)

from shared_state import PLACEHOLDER_IMAGE_URL

def fetch_latest_food_tile():
    response = requests.get("https://www.themealdb.com/api/json/v1/1/random.php")
    if response.status_code != 200:
        return None

    data = response.json()
    meal = data["meals"][0]

    return {
        "title": meal["strMeal"],
        "img_url": meal["strMealThumb"]
    }

def render_food_tile(img_url, image_title):
    with open(FOOD_AND_DRINK_TEMPLATE_PATH, "r") as f:
        template = f.read()
    return template.format(img_url=img_url, image_title=image_title).encode("utf-8")


def handle_request(flow: http.HTTPFlow):
    # Once here, immediately set flow.response and mitmproxy will never resolve the host
    print(f"[Food & Drink] Intercepted: {flow.request.pretty_url}")
    latest_tile = fetch_latest_food_tile()
    if latest_tile:
        data = render_food_tile(latest_tile["img_url"], latest_tile["title"])
    flow.response = http.Response.make(
        200,
        data,
        {"Content-Type": "application/xml; charset=utf-8"}
    )
