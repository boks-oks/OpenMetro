import os
import re
import feedparser
from html import unescape
from xml.sax.saxutils import escape
from mitmproxy import http
from shared_state import ERROR_TILE_PATH

URL_PATTERN = "finance.services.appex.bing.com"
FINANCE_TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "..", "Tiles", "finance.xml")

RSS_FEED_URL = "https://www.cnbc.com/id/10000664/device/rss/rss.html"

DEFAULT_IMG_URL = "https://placehold.co/100x100/transparent/FFFFFF?text=$"  # fallback image for tile

def fetch_finance_story():
    feed = feedparser.parse(RSS_FEED_URL)
    for entry in feed.entries:
        # Try to find an image in content or media (likely none for CNBC, so fallback)
        content = entry.get("content", [{}])[0].get("value", "")
        matches = re.findall(r"<img\s+[^>]*src=['\"]([^'\"]+)['\"]", content)
        img_url = matches[0] if matches else DEFAULT_IMG_URL
        
        return {
            "title": unescape(entry.title),
            "img_url": img_url
        }
    return None

def render_finance_tile(img_url, title):
    with open(FINANCE_TEMPLATE_PATH, "r", encoding="utf-8") as f:
        template = f.read()
    return template.format(img_url=img_url, article_text=title)

def handle_request(flow: http.HTTPFlow):
    # Only intercept the AppTileV2 call on finance.services.appex.bing.com
    host = flow.request.host.lower()
    path = flow.request.path.lower()

    if host == "finance.services.appex.bing.com" and "market.svc/apptilev2" in path:
        print(f"[Finance] Intercepted: {flow.request.pretty_url}")

        data = fetch_finance_story()
        if data:
            # Resize image via images.weserv.nl or use fallback img if none
            resized_url = f"https://images.weserv.nl/?url={data['img_url']}&w=400&h=400&fit=cover"
            safe_url = escape(resized_url, {'"': '&quot;'})
            safe_title = escape(data["title"])
            tile_str = render_finance_tile(safe_url, safe_title)
        else:
            with open(ERROR_TILE_PATH, "r", encoding="utf-8") as f:
                tile_str = f.read()

        flow.response = http.Response.make(
            200,
            tile_str.encode("utf-8"),
            {"Content-Type": "application/xml; charset=utf-8"}
        )
