import asyncio
from mitmproxy import http
import requests

# Import the new, modularized components
from modules import location, weather, news, foodanddrink, healthandfitness, games, travel, sports, finance
import shared_state

from modules.weather import ACCUWEATHER_IMAGE_MAP, total_accuweather_images
class OpenMetro:
    valid_accuweather_images = 0

    for i in ACCUWEATHER_IMAGE_MAP:
        # Test all image URLs.
        response = requests.head(ACCUWEATHER_IMAGE_MAP[i])
        if response.status_code == 200:
            print(f"Image URL for {i} is valid.")
            valid_accuweather_images += 1
        else:
            print(f"Image URL for {i} is invalid. Check the URL.")
            # Raise a value error with details.
            raise ValueError(f"Invalid image URL for {i}: {ACCUWEATHER_IMAGE_MAP[i]}")
        if valid_accuweather_images == total_accuweather_images:
            print(f"All {valid_accuweather_images} AccuWeather images are valid.")

    def load(self, loader):
        """
        This is a mitmproxy lifecycle hook that runs on startup.
        We use it to start our background tasks, like fetching the user's location
        and starting the periodic weather tile refresh.
        """
        if not shared_state.location_task_started:
            print("Main: Kicking off background tasks...")
            loop = asyncio.get_event_loop()
            loop.create_task(location.fetch_coords())
            loop.create_task(weather.periodic_tile_refresh())
            shared_state.location_task_started = True


    def request(self, flow: http.HTTPFlow):
        url = flow.request.pretty_url.lower()

        # Route modules that DON'T need coords first
        if healthandfitness.URL_PATTERN in url:
            healthandfitness.handle_request(flow)            
        elif news.URL_PATTERN in url:
            news.handle_request(flow)
        elif foodanddrink.URL_PATTERN in url:
            foodanddrink.handle_request(flow)
        elif games.URL_PATTERN in url:
            games.handle_request(flow)
        elif travel.URL_PATTERN in url:
            travel.handle_request(flow)
        elif sports.URL_PATTERN in url:
            sports.handle_request(flow)
        elif finance.URL_PATTERN in url:
            finance.handle_request(flow)


        if weather.URL_PATTERN in url:
            if not shared_state.coords:
                print("Waiting for location…")
                flow.response = http.Response.make(
                    503, b"Location not ready", {"Content-Type": "text/plain"}
                )
            else:
                weather.handle_request(flow)

    def response(self, flow: http.HTTPFlow):
        pass


addons = [
    OpenMetro()
]
